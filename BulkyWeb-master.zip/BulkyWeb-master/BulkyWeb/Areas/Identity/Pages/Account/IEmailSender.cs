﻿namespace BulkyWeb.Areas.Identity.Pages.Account
{
    internal interface IEmailSender<T>
    {
    }
}