﻿namespace BulkyWeb.Areas.Identity.Pages.Account
{
    internal class OtpService<T>
    {
        public static implicit operator OtpService<T>(OtpService v)
        {
            throw new NotImplementedException();
        }
    }
}